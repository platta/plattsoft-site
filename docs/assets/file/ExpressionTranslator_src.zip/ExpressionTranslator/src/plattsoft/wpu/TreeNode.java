/*
 * TreeNode.java
 *
 * Created on September 24, 2006, 1:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plattsoft.wpu;

/**
 *
 * @author platta
 */
public class TreeNode {
    
    //<editor-fold defaultstate="collapsed" desc="Constructors">
    // Default constructor
    public TreeNode() {
        parent = null;
        left = null;
        right = null;
        value = "";
    }
    
    public TreeNode( String theValue ) {
        super();
        value = theValue;
    }
    //</editor-fold>
    
    //<editor-fold defaultstate="collapsed" desc="Accessors and Modifiers">
    //parent
    public void setParent(TreeNode theParent) {
        parent = theParent;
    }
    
    public TreeNode getParent() {
        return parent;
    }
    
    //left
    public void setLeft( TreeNode theLeft ) {
        left = theLeft;
        
        if( left != null )
            left.setParent(this);
    }
    
    public TreeNode getLeft() {
        return left;
    }
    
    //right
    public void setRight( TreeNode theRight ) {
        right = theRight;
        
        if( right != null )
            right.setParent(this);
    }
    
    public TreeNode getRight() {
        return right;
    }
    
    //value
    public void setValue( String theValue ) {
        value = theValue;
    }
    
    public String getValue() {
        return value;
    }
    //</editor-fold>

    //---------------------------------------------------
    //--- Member Variables
    //Link to the parent
    private TreeNode parent;
    
    // Link to the two children
    private TreeNode left;
    private TreeNode right;
    
    // Store the value of this node
    private String value;
}
