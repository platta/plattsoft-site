/*
 * TreeTraverser.java
 *
 * Created on September 24, 2006, 2:20 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plattsoft.wpu;

import java.util.Stack;

/**
 *
 * @author platta
 */
public class TreeTraverser {
    
    /** Creates a new instance of TreeTraverser */
    public TreeTraverser() {
    }

    public String getPrefix(TreeNode tree) {
        String s = "";
        
        // can't do anything if there's no tree
        if( tree == null )
            return s;
        
        // Root
        s += tree.getValue();
        
        // Left
        s += " " + getPrefix(tree.getLeft()).trim();
        
        // Right
        s += " " + getPrefix(tree.getRight()).trim();
        
        return s;
    }
    
    public String getInfix( TreeNode tree ) {
        String s = "";
        int rootPrecedence, leftPrecedence, rightPrecedence;
        
        // can't do anything if there's no tree
        if( tree == null )
            return s;
        
        
        //------------------------------------------------
        // Figure out the precedence of all the operators
        // We need this to determine if we need parens
        // Any time an operation of lower precedence executes
        // Before an operation of higher precedence, we need to
        // Enclose the lower precedence operation in parens.
        // In order to keep things working, we'll give digits the highest
        // precedence of all
        rootPrecedence = getOperatorPrecedence(tree.getValue());
        
        if( tree.getLeft() != null )
            leftPrecedence = getOperatorPrecedence( tree.getLeft().getValue());
        else
            leftPrecedence = 2;
        
        if( tree.getRight() != null )
            rightPrecedence = getOperatorPrecedence( tree.getRight().getValue());
        else
            rightPrecedence = 2;
        
        //-----------------------------------------------------
        // Now build the string
        //Left
        if( rootPrecedence > leftPrecedence )
            s += "( " + getInfix(tree.getLeft()).trim() + " )";
        else
            s += getInfix(tree.getLeft()).trim();
        
        // Root
        s += " " + tree.getValue();
        
        // Right
        // The right hand is a little different.  In this case, even if an operation
        // of equal precedence is on the right branch, since it's executing out of order,
        // it needs parens
        if( rootPrecedence > rightPrecedence || ( rootPrecedence < 2 && rightPrecedence == rootPrecedence ) )   
                s += " ( " + getInfix(tree.getRight()).trim() + " )";
            else
                s += " " + getInfix(tree.getRight()).trim();
        
        return s;
    }

    public String getPostfix( TreeNode tree ) {
        String s = "";
        
        // can't do anything if there's no tree
        if( tree == null )
            return s;
        
        // Left
        s += getPostfix( tree.getLeft() ).trim();
        
        // Right
        s += " " + getPostfix( tree.getRight() ).trim();
        
        // Root
        s += " " + tree.getValue();
        
        return s;
    }
    
    private int getOperatorPrecedence( String token ) {
        if( token.compareTo("+") == 0 || token.compareTo("-") == 0 )
            // + or -, lowest precedence
            return 0;
        else if( token.compareTo("*") == 0 || token.compareTo("/") == 0 )
            // * or /, higher precedence
            return 1;
        else
            // must be a digit, they have the highest precedence
            return 2;
    }
    
    public float getFloatValue( TreeNode tree ) {
        
        if( tree == null )
            return 0;
        
        if( tree.getLeft() == null || tree.getRight() == null )
            return Float.valueOf(tree.getValue());
        
        String rootValue = tree.getValue();
        if( rootValue.compareTo("+") == 0 )
            return getFloatValue(tree.getLeft()) + getFloatValue( tree.getRight() );
        else if( rootValue.compareTo("-") == 0)
            return getFloatValue(tree.getLeft()) - getFloatValue( tree.getRight());
        else if( rootValue.compareTo("*") == 0 )
            return getFloatValue(tree.getLeft()) * getFloatValue( tree.getRight());
        else if( rootValue.compareTo("/") == 0)
            return getFloatValue(tree.getLeft()) / getFloatValue( tree.getRight());
        else
            return 0;
    }
    
}
