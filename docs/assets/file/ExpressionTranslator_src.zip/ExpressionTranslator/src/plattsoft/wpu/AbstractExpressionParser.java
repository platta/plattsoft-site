/*
 * AbstractExpressionParser.java
 *
 * Created on September 24, 2006, 2:07 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plattsoft.wpu;

import java.util.regex.Pattern;

/**
 *
 * @author platta
 */
public abstract class AbstractExpressionParser {
    
    /**
     * Creates a new instance of AbstractExpressionParser
     */
    public AbstractExpressionParser() {
        output = "";
    }
    
    // This method is just a wrapper to get the expression in place
    // so that implementations of the abstract method don't have to remember to
    public TreeNode buildTreeFromExpression( String theExpression ) {
        expression = theExpression;
        return buildTree();
    }
    
    // Here is where the sub-classes will implement everything
    protected abstract TreeNode buildTree();
    
    // Token grabber
    protected String getNextToken() {
        String theToken;
        int position;
        
        // Find the next space
        position = expression.indexOf(32);
        
        if( position > 0) {
            // If we found a space somewhere after the first character
            theToken = expression.substring(0,position);
            expression = expression.substring(position+1);
        } else {
            //If there is no space, we are on the last token
            theToken = expression;
            expression = "";
        }
        return theToken.trim();
    }
    
    // Numeric Checker
    protected boolean isNumeric( String theToken ) {
        // use regulaer expressions to check if a token is numeric
        return Pattern.matches("-?\\d+\\.?\\d*",theToken);
    }
    
    //<editor-fold defaultstate="collapsed" desc="Accessors and Modifiers">
    // Expression
    public void setExpression( String theExpression ) {
        expression = theExpression;
    }
    
    public String getOutput() {
        return output;
    }
    
    public String getExpression() {
        return expression;
    }
    //</editor-fold>
    
    //-------------------------------------------
    //--- Member Variables
    //The expression itself
    protected String expression;
    protected String output;
    
    
}
