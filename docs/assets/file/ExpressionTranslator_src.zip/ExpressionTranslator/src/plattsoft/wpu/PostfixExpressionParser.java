/*
 * PostfixExpressionParser.java
 *
 * Created on September 24, 2006, 3:26 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plattsoft.wpu;

import java.util.Stack;

/**
 *
 * @author platta
 */
public class PostfixExpressionParser extends AbstractExpressionParser {

    protected TreeNode buildTree() {
        String token = "";
        TreeNode leftNode, rightNode, rootNode;
        Stack<TreeNode> theStack = new Stack<TreeNode>();
        
        // Get the first token
        token = getNextToken();
        
        while( token.trim().length() != 0 ) {
            
            // Check what type of token we have
            if( isNumeric(token) ) {
                //We have a numeric token, push it on the stack
                output += "Push " + token + "\n";
                theStack.push(new TreeNode(token));
            } else {
                // It's an operator, pop two operands and push the resulting node
                if( !theStack.empty() ) {
                    rightNode = theStack.pop();
                    output += "Pop " + rightNode.getValue() + "\n";
                } else {
                    output += "Empty Stack: Expecting Operand\n";
                    return null;
                }
                
                if( !theStack.empty() ) {
                    leftNode = theStack.pop();
                    output += "Pop " + leftNode.getValue() + "\n";
                } else {
                    output += "Empty Stack: Expecting Operand\n";
                    return null;
                }
                
                rootNode = new TreeNode(token);
                rootNode.setLeft(leftNode);
                rootNode.setRight(rightNode);
                theStack.push(rootNode);
                output += "Combine Nodes " + leftNode.getValue() + " " + rootNode.getValue() + " " + rightNode.getValue() + "\n";
                output += "Push New Node\n";
                
                rootNode = null;
                leftNode = null;
                rightNode = null;
            }
            
            //Get the next token
            token = getNextToken();
        }
        
        
        rootNode = theStack.pop();
        
        if( !theStack.empty() ) {
            output += "Stack Not Empty: It Should Be\n";
            return null;
        }
        
        return rootNode;
    }
    
}
