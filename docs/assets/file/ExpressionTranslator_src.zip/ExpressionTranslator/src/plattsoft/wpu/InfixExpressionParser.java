/*
 * InfixExpressionParser.java
 *
 * Created on September 24, 2006, 2:35 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plattsoft.wpu;

import javax.swing.JOptionPane;

/**
 *
 * @author platta
 */
public class InfixExpressionParser extends AbstractExpressionParser {
    
    protected TreeNode buildTree() {
        String token = "";
        TreeNode treeRoot = null;
        TreeNode tempNode = null;
        boolean precedenceOverride = false;
        
        // Get the first token
        token = getNextToken();
        
        while( token.trim().length() != 0 ) {
            
            if( isNumeric(token) ) {
                // We have a numeric token
                output += "Encountered Number " + token + "\n";
                if( treeRoot == null ) {
                    // First number
                    output += "No Root Node: Become Root\n";
                    treeRoot = new TreeNode(token);
                } else {
                    // Any other number
                    tempNode = treeRoot;
                    output += "Root Node Populated, Go Right\n";
                    while( tempNode.getRight() != null ) {
                        output += "Keep Going...\n";
                        tempNode = tempNode.getRight();
                    }
                    output += "Become Rightmost Leaf\n";
                    tempNode.setRight( new TreeNode( token ));
                }
            } else {
                // Some other kind of token
                if( token.compareTo("+") == 0 ||
                        token.compareTo("-") == 0 ||
                        token.compareTo("*") == 0 ||
                        token.compareTo("/") == 0 ) {
                    output += "Encountered Operator " + token + "\n";
                    // This is an operator
                    if( isNumeric( treeRoot.getValue()) ) {
                        // There is a number on the root...take over
                        output += "Root Node is a Number.  Become Root Node\n";
                        tempNode = treeRoot;
                        treeRoot = new TreeNode( token );
                        treeRoot.setLeft( tempNode );
                    } else {
                        // There is an operator on the root...need to worry about precedence
                        output += "Root Node is an Operator.  Check Precedence\n";
                        if( !precedenceOverride && getOperatorPrecedence( treeRoot.getValue() ) < getOperatorPrecedence( token ) ) {
                            if( precedenceOverride ) {
                                output += "Precedence Override Flagged: ";
                                precedenceOverride = false;    
                            } else
                                output += "Operator has Higher Precedence: ";
                            output += "Take Over the Node to the Right of the Root\n";
                            tempNode = treeRoot.getRight();
                            treeRoot.setRight( new TreeNode( token ) );
                            treeRoot.getRight().setLeft( tempNode );
                            
                        } else {
                            output += "Operator has Lower Precedence: Become the New Root\n";
                            tempNode = treeRoot;
                            treeRoot = new TreeNode( token );
                            treeRoot.setLeft( tempNode );
                        }
                    }
                } else if ( token.compareTo("(") == 0 ) {
                    // Opening Parenthesis, recurse and make the result the right of the root
                    output += "Encountered Operator ( - Need to Recurse\n";
                    if( treeRoot != null ) {
                        output += "Root Node is Populated: Use the Rightmost Node\n";
                        tempNode = treeRoot;
                        while( tempNode.getRight() != null )
                            tempNode = tempNode.getRight();
                    
                        tempNode.setRight( buildTree() );
                    } else {
                        output += "Root Node is not Populated: Use the Root Node\n";
                        treeRoot = buildTree();
                        output += "Setting Precedence Override Flag\n";
                        precedenceOverride = true;
                    }
                } else if ( token.compareTo(")") == 0 ) {
                    // Closing parenthesis
                    output += "Encountered Operator ) - Exit Recursion\n";
                    tempNode = null;
                    return treeRoot;
                } else {
                    // Unknown, gtfo
                    output += "Unknown Operator\n";
                    return null;
                }
                
            }
            
            // Get the next token
            token = getNextToken();
        }
        
        return treeRoot;
    }
    
    private int getOperatorPrecedence( String token ) {
        if( token.compareTo("+") == 0 || token.compareTo("-") == 0 )
            // + or -, lowest precedence
            return 0;
        else if( token.compareTo("*") == 0 || token.compareTo("/") == 0 )
            // * or /, higher precedence
            return 1;
        else
            // must be a digit, they have the highest precedence
            return 2;
    }
}
