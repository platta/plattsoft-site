/*
 * PrefixExpressionParser.java
 *
 * Created on September 24, 2006, 4:00 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package plattsoft.wpu;

import java.util.Stack;

/**
 *
 * @author platta
 */
public class PrefixExpressionParser extends AbstractExpressionParser {
    
    protected TreeNode buildTree() {
        String token = "";
        TreeNode leftNode, rightNode, rootNode = null, tokenNode;
        Stack<TreeNode> theStack = new Stack<TreeNode>();
        
        // Get the first token
        token = getNextToken();
        
        while( token.trim().length() != 0 ) {
        
            // See what kind of token we have
            if( isNumeric(token) ) {
                // This is a number, use a nested loop to calculate
                tokenNode = new TreeNode( token );
                output += "Found Number\n";
                while( tokenNode != null ) {
                    // Check the next value on the stack
                    if( !theStack.empty() && (isNumeric( theStack.peek().getValue()) || theStack.peek().getLeft() != null)) {
                        // There is another number on the stack
                        leftNode = theStack.pop();
                        output += "Pop " + leftNode.getValue() + "\n";
                        rightNode = tokenNode;
                        
                        // Expect an operator to be here
                        if( !theStack.empty() && !isNumeric( theStack.peek().getValue()) && theStack.peek().getLeft() == null ) {
                            // Found an operator!
                            rootNode = theStack.pop();
                            output += "Pop " + rootNode.getValue() + "\n";
                        } else {
                            // Oops!
                            output += "Empty Stack: Expecting Operator\n";
                            return null;
                        }
                        
                        rootNode.setLeft(leftNode);
                        rootNode.setRight(rightNode);
                        tokenNode = rootNode;
                        output += "Combine Nodes " + leftNode.getValue() + " " + rootNode.getValue() + " " + rightNode.getValue() + "\n";
                        
                        rootNode = null;
                        leftNode = null;
                        rightNode = null;
                    } else {
                        // push!
                        output += "Push " + tokenNode.getValue() + "\n";
                        theStack.push( tokenNode );
                        tokenNode = null;
                    }
                }
            } else {
                output += "Push " + token + "\n";
                theStack.push( new TreeNode(token));
            }
            
            // Get the next token
            token = getNextToken();
        }
              
        if( !theStack.empty() )
            rootNode = theStack.pop();
        
        if( !theStack.empty()) {
            output += "Stack Not Empty: It Should Be\n";
            return null;
        }
        
        return rootNode;
    }
    
}
